# TensorGuard QA Summary

- **Date**: 2026-01-04T12:24:04.578520
- **Duration**: 7.10s
- **Pass Rate**: 0.0%

| Metric | Count |
|---|---|
| Total | 8 |
| Passed | 0 |
| Failed | 0 |
| Errors | 8 |
| Skipped | 0 |

## 🚨 Failed Tests

### ::tests.integration.test_bench_evidence
```text
collection failure
```
### ::tests.integration.test_platform_api
```text
collection failure
```
### ::tests.integration.test_tgsp
```text
collection failure
```
### ::tests.integration.test_tgsp_platform
```text
collection failure
```
### ::tests.security.test_platform_security
```text
collection failure
```
### ::tests.security.test_quantum_safety
```text
collection failure
```
### ::tests.test_edge_resilience
```text
collection failure
```
### ::tests.test_moai_flow
```text
collection failure
```
