"""
TensorGuard Unified Cryptography Layer
Implements Classic, PQC, and Hybrid primitives.
"""
