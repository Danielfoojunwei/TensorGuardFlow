from .spec import VERSION
