"""
TensorGuard Observability
"""
from .metrics import TOTAL_REQUESTS, LATENCY_SECONDS
from .otel import setup_otel
