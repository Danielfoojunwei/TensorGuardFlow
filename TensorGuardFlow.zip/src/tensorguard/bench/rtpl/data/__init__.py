"""RTPL Data Loading - PCAP parsing and synthetic dataset generation."""
