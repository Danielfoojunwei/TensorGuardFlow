"""RTPL Attack Reproduction Pipeline - command detection and classification."""
