"""Key Provider Abstraction - Secure key storage."""
