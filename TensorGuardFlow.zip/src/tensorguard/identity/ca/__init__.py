"""Private CA Integration - Internal certificate authority for mTLS."""
